//
//  ContentView.swift
//  Group-Project
//
//  Created by Jayanth Uppalapati on 12/08/24.
//

import SwiftUI
import MapKit
import PhotosUI

// MARK: - Event Model
struct Event: Identifiable, Codable {
    let id: UUID
    let name: String
    let date: String
    let time: String
    let venue: String
    let description: String
    let category: String
    var coordinate: CLLocationCoordinate2D

    // Custom Keys
    enum CodingKeys: String, CodingKey {
        case id, name, date, time, venue, description, category, latitude, longitude
    }

    // Encoding
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id, forKey: .id)
        try container.encode(name, forKey: .name)
        try container.encode(date, forKey: .date)
        try container.encode(time, forKey: .time)
        try container.encode(venue, forKey: .venue)
        try container.encode(description, forKey: .description)
        try container.encode(category, forKey: .category)
        try container.encode(coordinate.latitude, forKey: .latitude)
        try container.encode(coordinate.longitude, forKey: .longitude)
    }

    // Decoding
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(UUID.self, forKey: .id)
        name = try container.decode(String.self, forKey: .name)
        date = try container.decode(String.self, forKey: .date)
        time = try container.decode(String.self, forKey: .time)
        venue = try container.decode(String.self, forKey: .venue)
        description = try container.decode(String.self, forKey: .description)
        category = try container.decode(String.self, forKey: .category)
        let latitude = try container.decode(Double.self, forKey: .latitude)
        let longitude = try container.decode(Double.self, forKey: .longitude)
        coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }

    // Custom Initializer
    init(id: UUID = UUID(), name: String, date: String, time: String, venue: String, description: String, category: String, coordinate: CLLocationCoordinate2D) {
        self.id = id
        self.name = name
        self.date = date
        self.time = time
        self.venue = venue
        self.description = description
        self.category = category
        self.coordinate = coordinate
    }
}

// MARK: - Sample Events
let sampleEvents = [
    Event(name: "Role Model", date: "Tue, May 11", time: "8:30 PM", venue: "Radio City Music Hall", description: "A night of indie pop music.", category: "Concert", coordinate: CLLocationCoordinate2D(latitude: 40.73061, longitude: -73.935242)),
    Event(name: "Perfume Genius", date: "Tue, May 31", time: "7:30 PM", venue: "NuBlu Classic", description: "A journey through soulful melodies.", category: "Concert", coordinate: CLLocationCoordinate2D(latitude: 40.7505, longitude: -73.9934)),
    Event(name: "Hackathon 2024", date: "Mon, Jun 14", time: "9:00 AM", venue: "MSU Campus", description: "A 24-hour hackathon where students solve real-world problems with coding.", category: "Tech Event", coordinate: CLLocationCoordinate2D(latitude: 40.7423, longitude: -74.1790)),
    Event(name: "Career Fair", date: "Wed, Jun 21", time: "10:00 AM", venue: "University Center", description: "Meet top companies offering internships and full-time positions.", category: "Career", coordinate: CLLocationCoordinate2D(latitude: 40.7431, longitude: -74.1778)),
    Event(name: "Photography Workshop", date: "Sat, Jul 10", time: "2:00 PM", venue: "Room 304, MSU", description: "Learn photography basics and tips from an expert.", category: "Workshop", coordinate: CLLocationCoordinate2D(latitude: 40.7421, longitude: -74.1805)),
    Event(name: "Sports Day", date: "Fri, Aug 5", time: "10:00 AM", venue: "Main Field", description: "A fun-filled day of sports including soccer, basketball, and relay races.", category: "Sports", coordinate: CLLocationCoordinate2D(latitude: 40.7439, longitude: -74.1787)),
    Event(name: "Coding Bootcamp", date: "Sun, Sep 12", time: "11:00 AM", venue: "Library Auditorium", description: "Intensive bootcamp on Python and machine learning concepts.", category: "Workshop", coordinate: CLLocationCoordinate2D(latitude: 40.7445, longitude: -74.1793)),
    Event(name: "Study Group: Finals Prep", date: "Tue, Dec 5", time: "6:00 PM", venue: "Student Lounge", description: "Prepare for finals with peers. Notes, quizzes, and study plans included.", category: "Study Group", coordinate: CLLocationCoordinate2D(latitude: 40.7434, longitude: -74.1762))
]


// MARK: - Event View Model
class EventViewModel: ObservableObject {
    @Published var events: [Event] = sampleEvents
    @Published var favorites: [Event] = []
    @Published var searchText: String = ""

    var filteredEvents: [Event] {
        if searchText.isEmpty {
            return events
        }
        return events.filter { event in
            event.name.localizedCaseInsensitiveContains(searchText) ||
            event.description.localizedCaseInsensitiveContains(searchText)
        }
    }

    func toggleFavorite(event: Event) {
        if let index = favorites.firstIndex(where: { $0.id == event.id }) {
            favorites.remove(at: index)
        } else {
            favorites.append(event)
        }
    }

    func isFavorite(event: Event) -> Bool {
        favorites.contains(where: { $0.id == event.id })
    }
}

// MARK: - Main ContentView
struct ContentView: View {
    @StateObject private var viewModel = EventViewModel()
    @State private var isLoggedIn = false
    @State private var showSignUp = false

    var body: some View {
        if isLoggedIn {
            MainAppView(viewModel: viewModel, isLoggedIn: $isLoggedIn)
        } else {
            if showSignUp {
                SignUpView(isLoggedIn: $isLoggedIn, showSignUp: $showSignUp)
            } else {
                LoginView(isLoggedIn: $isLoggedIn, showSignUp: $showSignUp)
            }
        }
    }
}

// MARK: - MainAppView
struct MainAppView: View {
    @ObservedObject var viewModel: EventViewModel
    @Binding var isLoggedIn: Bool

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.purple, Color.blue]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)

            TabView {
                HomeView(viewModel: viewModel)
                    .tabItem {
                        Label("Home", systemImage: "house")
                    }
                ExploreView(viewModel: viewModel)
                    .tabItem {
                        Label("Explore", systemImage: "magnifyingglass")
                    }
                FavoritesView(viewModel: viewModel)
                    .tabItem {
                        Label("Favorites", systemImage: "heart")
                    }
                ProfileView(isLoggedIn: $isLoggedIn)
                    .tabItem {
                        Label("Profile", systemImage: "person")
                    }
            }
        }
    }
}

// MARK: - LoginView
struct LoginView: View {
    @Binding var isLoggedIn: Bool
    @Binding var showSignUp: Bool
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var showAlert: Bool = false
    @State private var alertMessage: String = ""

    var body: some View {
        ZStack {
            // Background Image
            Image("login_concert_bg")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()

            // Gradient Overlay
            LinearGradient(gradient: Gradient(colors: [Color.black.opacity(0.6), Color.clear]),
                           startPoint: .bottom, endPoint: .top)
                .ignoresSafeArea()

            VStack(spacing: 20) {
                Spacer()

                // Title
                Text("Event Hub")
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(.white)

                // Email Input
                TextField("Email", text: $email)
                    .padding()
                    .background(Color.white.opacity(0.9))
                    .cornerRadius(10)
                    .foregroundColor(.black)
                    .padding(.horizontal)

                // Password Input
                SecureField("Password", text: $password)
                    .padding()
                    .background(Color.white.opacity(0.9))
                    .cornerRadius(10)
                    .foregroundColor(.black)
                    .padding(.horizontal)

                // Login Button
                Button(action: {
                    login()
                }) {
                    Text("Login")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.orange)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding(.horizontal)

                // Sign Up Button
                Button(action: {
                    showSignUp = true
                }) {
                    Text("Create Account")
                        .foregroundColor(.white)
                        .underline()
                }

                Spacer()
            }
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Error"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
        }
    }

    private func login() {
        // Retrieve stored credentials
        if let storedEmail = UserDefaults.standard.string(forKey: "userEmail"),
           let storedPassword = UserDefaults.standard.string(forKey: "userPassword") {

            // Validate credentials
            if email == storedEmail && password == storedPassword {
                isLoggedIn = true
            } else {
                alertMessage = "Invalid email or password."
                showAlert = true
            }
        } else {
            alertMessage = "No account found. Please sign up first."
            showAlert = true
        }
    }
}




// MARK: - SignUpView
struct SignUpView: View {
    @Binding var isLoggedIn: Bool
    @Binding var showSignUp: Bool
    @State private var name: String = ""
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var showAlert: Bool = false
    @State private var alertMessage: String = ""

    var body: some View {
        ZStack {
            // Background Image
            Image("login_concert_bg")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()

            // Gradient Overlay
            LinearGradient(gradient: Gradient(colors: [Color.black.opacity(0.6), Color.clear]),
                           startPoint: .bottom, endPoint: .top)
                .ignoresSafeArea()

            VStack(spacing: 20) {
                Spacer()

                // Title
                Text("Sign Up")
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(.white)

                // Name Field
                TextField("Name", text: $name)
                    .padding()
                    .background(Color.white.opacity(0.9))
                    .cornerRadius(10)
                    .foregroundColor(.black)
                    .padding(.horizontal)

                // Email Field
                TextField("Email", text: $email)
                    .padding()
                    .background(Color.white.opacity(0.9))
                    .cornerRadius(10)
                    .foregroundColor(.black)
                    .padding(.horizontal)

                // Password Field
                SecureField("Password", text: $password)
                    .padding()
                    .background(Color.white.opacity(0.9))
                    .cornerRadius(10)
                    .foregroundColor(.black)
                    .padding(.horizontal)

                // Sign Up Button
                Button(action: {
                    signUp()
                }) {
                    Text("Sign Up")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding(.horizontal)

                // Back to Login Button
                Button(action: {
                    showSignUp = false
                }) {
                    Text("Back to Login")
                        .foregroundColor(.white)
                        .underline()
                }

                Spacer()
            }
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Error"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
        }
    }

    private func signUp() {
        if name.isEmpty || email.isEmpty || password.isEmpty {
            alertMessage = "All fields are required."
            showAlert = true
        } else {
            // Store credentials locally
            UserDefaults.standard.set(name, forKey: "userName")
            UserDefaults.standard.set(email, forKey: "userEmail")
            UserDefaults.standard.set(password, forKey: "userPassword")

            isLoggedIn = true
        }
    }
}


// MARK: - HomeView
struct HomeView: View {
    @ObservedObject var viewModel: EventViewModel

    var body: some View {
        NavigationView {
            ZStack {
                //  Background Color
                Color(UIColor.systemGray6) // Light gray background
                    .edgesIgnoringSafeArea(.all)

                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        // Section Title
                        Text("Upcoming Events")
                            .font(.largeTitle)
                            .bold()
                            .foregroundColor(.orange)
                            .padding(.leading)

                        // Event Cards
                        ForEach(viewModel.filteredEvents) { event in
                            NavigationLink(destination: EventDetailView(event: event, viewModel: viewModel)) {
                                EventCard(event: event, isFavorite: viewModel.isFavorite(event: event))
                                    .padding(.horizontal)
                            }
                        }
                    }
                    .padding(.top, 20)
                }
            }
            .searchable(text: $viewModel.searchText)
            .navigationTitle("Home")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

// MARK: - ExploreView
struct ExploreView: View {
    @ObservedObject var viewModel: EventViewModel

    // Montclair State University Map Region
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 40.8634, longitude: -74.1952), // Montclair State University coordinates
        span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
    )

    // red pin coordinates
    let redPins = [
        CLLocationCoordinate2D(latitude: 40.8642, longitude: -74.1965),
        CLLocationCoordinate2D(latitude: 40.8628, longitude: -74.1943),
        CLLocationCoordinate2D(latitude: 40.8637, longitude: -74.1935),
        CLLocationCoordinate2D(latitude: 40.8640, longitude: -74.1950)
    ]

    var body: some View {
        NavigationView {
            VStack {
                // Map with Events and Red Pins
                Map(coordinateRegion: $region, annotationItems: combinedPins()) { pin in
                    MapPin(coordinate: pin.coordinate, tint: pin.isRed ? .red : .purple)
                }
                .frame(height: 300)
                .cornerRadius(15)
                .shadow(radius: 5)

                // Event List
                ScrollView {
                    VStack(spacing: 15) {
                        ForEach(viewModel.filteredEvents) { event in
                            NavigationLink(destination: EventDetailView(event: event, viewModel: viewModel)) {
                                EventCard(event: event, isFavorite: viewModel.isFavorite(event: event))
                            }
                        }
                    }
                }
                .padding(.horizontal)
            }
            .navigationTitle("Explore")
        }
    }

    // Combine Events and Red Pins
    private func combinedPins() -> [MapPinItem] {
        var pins = viewModel.events.map { MapPinItem(coordinate: $0.coordinate, isRed: false) }
        pins.append(contentsOf: redPins.map { MapPinItem(coordinate: $0, isRed: true) })
        return pins
    }
}

// MARK: - Map Pin Item
struct MapPinItem: Identifiable {
    let id = UUID()
    let coordinate: CLLocationCoordinate2D
    let isRed: Bool
}
// MARK: - MapView with Pins
struct MapViewWithPins: View {
    let pins: [CLLocationCoordinate2D]
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 40.7423, longitude: -74.1785),
        span: MKCoordinateSpan(latitudeDelta: 0.002, longitudeDelta: 0.002)
    )

    var body: some View {
        Map(coordinateRegion: $region, annotationItems: pins.map { Pin(coordinate: $0) }) { pin in
            MapPin(coordinate: pin.coordinate, tint: .orange)
        }
    }
}

struct Pin: Identifiable {
    let id = UUID()
    let coordinate: CLLocationCoordinate2D
}
// MARK: - FavoritesView
struct FavoritesView: View {
    @ObservedObject var viewModel: EventViewModel

    //  grid layout
    let columns = [
        GridItem(.flexible(), spacing: 20),
        GridItem(.flexible(), spacing: 20)
    ]

    // pins inside university coordinates
    let universityPins = [
        CLLocationCoordinate2D(latitude: 40.7423, longitude: -74.1785),
        CLLocationCoordinate2D(latitude: 40.7431, longitude: -74.1792),
        CLLocationCoordinate2D(latitude: 40.7439, longitude: -74.1767),
        CLLocationCoordinate2D(latitude: 40.7428, longitude: -74.1774)
    ]

    var body: some View {
        NavigationView {
            ZStack {
                // Background Color
                Color(UIColor.systemGray6)
                    .edgesIgnoringSafeArea(.all)

                VStack(spacing: 20) {
                    // Map Section
                    MapViewWithPins(pins: universityPins)
                        .frame(height: 250)
                        .cornerRadius(20)
                        .shadow(radius: 5)
                        .padding(.horizontal)

                    // Favorites Section
                    ScrollView {
                        VStack(alignment: .leading) {
                            Text("Favorites")
                                .font(.largeTitle)
                                .bold()
                                .foregroundColor(.orange)
                                .padding(.leading)

                            LazyVGrid(columns: columns, spacing: 20) {
                                ForEach(viewModel.favorites) { event in
                                    NavigationLink(destination: EventDetailView(event: event, viewModel: viewModel)) {
                                        EnhancedFavoriteCard(event: event)
                                    }
                                }
                            }
                            .padding()
                        }
                    }
                }
            }
            .navigationBarHidden(true)
        }
    }
}
// MARK: - Enhanced Card for Favorites
struct EnhancedFavoriteCard: View {
    let event: Event

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 15)
                .fill(Color.white)
                .shadow(color: Color.black.opacity(0.2), radius: 5, x: 0, y: 5)

            VStack(alignment: .leading, spacing: 10) {
                Text(event.name)
                    .font(.headline)
                    .bold()
                    .foregroundColor(.orange)
                    .lineLimit(1)
                    .truncationMode(.tail)

                Text("\(event.date) · \(event.time)")
                    .font(.caption)
                    .foregroundColor(.gray)

                Text(event.venue)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .lineLimit(1)
                    .truncationMode(.tail)

                Spacer()

                HStack {
                    Spacer()
                    Image(systemName: "heart.fill")
                        .foregroundColor(.red)
                }
            }
            .padding()
        }
        .frame(height: 150)
    }
}
// MARK: - Imagepicker
struct ImagePicker: UIViewControllerRepresentable {
    @Binding var selectedImage: UIImage?

    func makeUIViewController(context: Context) -> PHPickerViewController {
        var config = PHPickerConfiguration()
        config.filter = .images
        let picker = PHPickerViewController(configuration: config)
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        return Coordinator(self)
    }

    class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let parent: ImagePicker

        init(_ parent: ImagePicker) {
            self.parent = parent
        }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            picker.dismiss(animated: true)
            guard let provider = results.first?.itemProvider, provider.canLoadObject(ofClass: UIImage.self) else { return }

            provider.loadObject(ofClass: UIImage.self) { image, _ in
                DispatchQueue.main.async {
                    self.parent.selectedImage = image as? UIImage
                }
            }
        }
    }
}
// MARK: - ProfileView
struct ProfileView: View {
    @State private var name: String = UserDefaults.standard.string(forKey: "userName") ?? "John Doe"
    @State private var email: String = UserDefaults.standard.string(forKey: "userEmail") ?? "john.doe@example.com"
    @State private var profileImage: UIImage? = nil
    @State private var isEditing: Bool = false
    @State private var isImagePickerPresented: Bool = false
    @Binding var isLoggedIn: Bool

    var body: some View {
        ZStack {
            // Background
            LinearGradient(gradient: Gradient(colors: [Color.orange.opacity(0.6), Color.black]),
                           startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)

            VStack(spacing: 20) {
                Spacer()

                // Profile Image Section
                VStack {
                    if let image = profileImage {
                        Image(uiImage: image)
                            .resizable()
                            .frame(width: 120, height: 120)
                            .clipShape(Circle())
                            .shadow(radius: 5)
                    } else {
                        Image(systemName: "person.circle.fill")
                            .resizable()
                            .frame(width: 120, height: 120)
                            .foregroundColor(.white.opacity(0.8))
                            .clipShape(Circle())
                            .shadow(radius: 5)
                    }

                    Button(action: {
                        isImagePickerPresented = true
                    }) {
                        Text("Edit Profile Photo")
                            .font(.subheadline)
                            .foregroundColor(.white)
                            .underline()
                            .padding(.top, 5)
                    }
                    .sheet(isPresented: $isImagePickerPresented) {
                        ImagePicker(selectedImage: $profileImage)
                    }
                }

                Spacer()

                // User Info Section
                VStack(spacing: 15) {
                    Text("Profile")
                        .font(.largeTitle)
                        .bold()
                        .foregroundColor(.white)

                    // User Info Fields
                    VStack(alignment: .leading, spacing: 15) {
                        Text("User Info")
                            .font(.headline)
                            .foregroundColor(.orange)

                        
                        VStack {
                            if isEditing {
                                TextField("Name", text: $name)
                                    .padding()
                                    .background(Color.white.opacity(0.1))
                                    .cornerRadius(8)
                                    .foregroundColor(.white)

                                TextField("Email", text: $email)
                                    .padding()
                                    .background(Color.white.opacity(0.1))
                                    .cornerRadius(8)
                                    .foregroundColor(.white)
                                    .keyboardType(.emailAddress)
                            } else {
                                
                                Text(name)
                                    .padding()
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .background(Color.white.opacity(0.1))
                                    .cornerRadius(8)
                                    .foregroundColor(.white)

                                Text(email)
                                    .padding()
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .background(Color.white.opacity(0.1))
                                    .cornerRadius(8)
                                    .foregroundColor(.white)
                            }
                        }

                        // Edit/Save Button
                        Button(action: {
                            if isEditing {
                                saveProfile()
                            }
                            isEditing.toggle()
                        }) {
                            Text(isEditing ? "Save" : "Edit")
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(isEditing ? Color.green : Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }
                    }
                }
                .padding()
                .background(Color.black.opacity(0.5))
                .cornerRadius(15)
                .shadow(radius: 5)

                // Settings and Logout
                VStack(spacing: 10) {
                    Toggle("Enable Notifications", isOn: .constant(true))
                        .toggleStyle(SwitchToggleStyle(tint: .orange))
                        .foregroundColor(.white)

                    Button(action: {
                        isLoggedIn = false
                    }) {
                        Text("Logout")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.red)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                }
                .padding(.horizontal)

                Spacer()
            }
            .padding(.horizontal)
        }
    }

    // Save updated name and email to UserDefaults
    private func saveProfile() {
        UserDefaults.standard.set(name, forKey: "userName")
        UserDefaults.standard.set(email, forKey: "userEmail")
    }
}


// MARK: - EventCard
struct EventCard: View {
    let event: Event
    let isFavorite: Bool

    var body: some View {
        ZStack {
            // Solid White Background 
            RoundedRectangle(cornerRadius: 15)
                .fill(Color.white)
                .overlay(
                    RoundedRectangle(cornerRadius: 15)
                        .stroke(Color.orange, lineWidth: 2) // Orange border
                )
                .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 5)

            // Event Content
            HStack(spacing: 15) {
                VStack(alignment: .leading, spacing: 8) {
                    // Event Name
                    Text(event.name)
                        .font(.headline)
                        .foregroundColor(.orange)

                    // Date & Time
                    Text("\(event.date) · \(event.time)")
                        .font(.subheadline)
                        .foregroundColor(.gray)

                    // Venue
                    Text(event.venue)
                        .font(.footnote)
                        .foregroundColor(.secondary)
                }

                Spacer()

                // Favorite Icon
                if isFavorite {
                    Image(systemName: "heart.fill")
                        .resizable()
                        .frame(width: 25, height: 25)
                        .foregroundColor(.red)
                }
            }
            .padding()
        }
        .frame(maxWidth: .infinity, minHeight: 120) // Uniform card size
        .padding(.horizontal, 5) // Minor horizontal padding for spacing
    }
}

// MARK: - EventDetailView
struct EventDetailView: View {
    let event: Event
    @ObservedObject var viewModel: EventViewModel

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                // Event Name
                Text(event.name)
                    .font(.largeTitle)
                    .bold()

                // Date & Time
                HStack {
                    Image(systemName: "calendar")
                    Text("\(event.date) · \(event.time)")
                }
                .font(.subheadline)
                .foregroundColor(.gray)

                // Location
                HStack {
                    Image(systemName: "mappin.and.ellipse")
                    Text("Location: \(event.venue)")
                }
                .font(.body)

                // Category
                HStack {
                    Image(systemName: "tag.fill")
                    Text("Category: \(event.category)")
                }
                .font(.body)

                Divider()

                // Detailed Section
                Text("Event Details")
                    .font(.title2)
                    .bold()

                Text(event.description)
                    .font(.body)
                    .foregroundColor(.secondary)

                // New Details to Fill Space
                VStack(alignment: .leading, spacing: 10) {
                    Text("Hosted By: MSU Events Team")
                        .font(.body)
                        .foregroundColor(.gray)

                    Text("Fees: Free for all students")
                        .font(.body)
                        .foregroundColor(.gray)

                    Text("Event Type: \(event.category)")
                        .font(.body)
                        .foregroundColor(.gray)
                }

                Spacer()

                // Favorites Button
                Button(action: {
                    viewModel.toggleFavorite(event: event)
                }) {
                    Text(viewModel.isFavorite(event: event) ? "Remove from Favorites" : "Add to Favorites")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.orange)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .shadow(radius: 5)
                }
            }
            .padding()
        }
        .navigationTitle(event.name)
    }
}

// MARK: - Preview
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
