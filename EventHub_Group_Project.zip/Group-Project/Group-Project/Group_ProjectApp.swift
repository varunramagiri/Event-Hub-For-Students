//
//  Group_ProjectApp.swift
//  Group-Project
//
//  Created by Jayanth Uppalapati on 12/15/24.
//

import SwiftUI

@main
struct Group_ProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
